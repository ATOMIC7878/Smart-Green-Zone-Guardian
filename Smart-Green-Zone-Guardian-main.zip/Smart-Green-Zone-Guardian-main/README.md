<div align="center">

<!-- 🔥 ALERT THEMED HEADER -->
<img src="https://capsule-render.vercel.app/api?type=waving&color=0:1A0F0A,25:FF4500,50:FF6B00,75:FF8C00,100:1A0F0A&height=230&section=header&text=SMART%20GREEN%20ZONE%20GUARDIAN&fontSize=34&fontColor=ffffff&fontAlignY=38&desc=IoT%20%7C%20Fire%20Detection%20%7C%20Illegal%20Logging%20Monitoring&descAlignY=60&descSize=16&animation=fadeIn" />

<br/>

<!-- 🔥 TYPING ANIMATION -->
[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&weight=700&size=20&pause=1000&color=FF6B00&center=true&vCenter=true&width=900&lines=🔥+Early+Fire+Risk+Detection;🪓+Illegal+Logging+Monitoring;📡+ESP32+%7C+Sensors+%7C+Cloud;🚨+24x7+Real-Time+SMS+Alerts;🤖+IoT+Powered+Environmental+Protection)](https://git.io/typing-svg)

<br/>

<!-- 🔥 COLORFUL BADGES -->
![ESP32](https://img.shields.io/badge/ESP32-Controller-FF4500?style=for-the-badge)
![IoT](https://img.shields.io/badge/IoT-Live%20Monitoring-FF6B00?style=for-the-badge)
![Cloud](https://img.shields.io/badge/Cloud-Blynk%20%7C%20Firebase-FF8C00?style=for-the-badge)
![Embedded C](https://img.shields.io/badge/Embedded-C/C++-D35400?style=for-the-badge)
![Alerts](https://img.shields.io/badge/SMS-Instant%20Alerts-FF4500?style=for-the-badge)

<br/>

![Status](https://img.shields.io/badge/System-Active-FF6B00?style=flat-square)
![Mode](https://img.shields.io/badge/Monitoring-24x7-FF4500?style=flat-square)
![Protection](https://img.shields.io/badge/Zone-Green%20Protection-FF8C00?style=flat-square)

</div>

---

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 🔥 Project Overview

> **Smart Green Zone Guardian** is an **IoT-based environmental monitoring and protection system** designed to detect **early fire risks** and **illegal logging activities** in forests, plantations, and protected green zones.

The system continuously monitors:

<div align="center">

![Temperature](https://img.shields.io/badge/🌡️-Temperature-FF4500?style=for-the-badge)
![Humidity](https://img.shields.io/badge/💧-Humidity-FF6B00?style=for-the-badge)
![Smoke](https://img.shields.io/badge/🌫️-Smoke-FF8C00?style=for-the-badge)
![Gas](https://img.shields.io/badge/🧪-Gas-D35400?style=for-the-badge)
![Sound](https://img.shields.io/badge/🔊-Sound-FF4500?style=for-the-badge)
![Vibration](https://img.shields.io/badge/📳-Vibration-FF6B00?style=for-the-badge)

</div>

and provides **real-time cloud monitoring + instant SMS alerts**.

---

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 🚨 Problem Statement

Forests and green zones face major threats due to:

- 🔥 Rising temperatures & dry climate
- 🌲 Delayed forest fire detection
- 🪓 Illegal logging in remote areas
- 🚶 Dependence on manual patrols

Traditional systems are expensive and slow.

This project provides a **low-cost automated 24×7 solution**.

---

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## ⚙️ System Architecture

```text
📡 Sensor Layer
   ↓
🧠 ESP32 Processing Unit
   ↓
🚨 Threshold Logic Engine
   ↓
☁️ Cloud Dashboard
   ↓
📩 Instant SMS Alerts
```

<div align="center">

![ESP32](https://img.shields.io/badge/ESP32-Brain-FF4500?style=for-the-badge)
![Cloud](https://img.shields.io/badge/Cloud-Dashboard-FF6B00?style=for-the-badge)
![SMS](https://img.shields.io/badge/SMS-Alerts-FF8C00?style=for-the-badge)

</div>

---

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 🧩 Hardware Components

| 🔧 Component | 🎯 Purpose |
|---|---|
| ESP32 DevKit V1 | Main controller + Wi-Fi |
| BME280 | Temperature & humidity |
| DSM501A | Smoke / dust detection |
| MQ-135 | CO₂ & gas detection |
| KY-037 | Chainsaw sound detection |
| SW-420 | Axe vibration detection |
| OLED Display | Live monitoring |
| Siren | Emergency alert |

---

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 🔥 Fire Detection Logic

```text
IF
Temperature ↑
Humidity ↓
Smoke detected
Gas spikes ↑

THEN
🚨 FIRE ALERT
```

<div align="center">

![Fire Risk](https://img.shields.io/badge/ALERT-FIRE%20RISK-red?style=for-the-badge)
![Emergency](https://img.shields.io/badge/STATUS-CRITICAL-orange?style=for-the-badge)

</div>

---

## 🪓 Illegal Logging Detection

```text
Continuous chainsaw noise
+
Repeated axe vibrations

=
⚠️ LOGGING ALERT
```

<div align="center">

![Logging](https://img.shields.io/badge/DETECTION-ILLEGAL%20LOGGING-FF4500?style=for-the-badge)

</div>

---

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## ☁️ Cloud Monitoring

Supports:

<div align="center">

![Blynk](https://img.shields.io/badge/Blynk-Cloud-FF6B00?style=for-the-badge)
![Firebase](https://img.shields.io/badge/Firebase-Backend-FF8C00?style=for-the-badge)
![ThingSpeak](https://img.shields.io/badge/ThingSpeak-Analytics-D35400?style=for-the-badge)

</div>

Tracks:

- 🌡️ Temperature trends
- 🌫️ Smoke level
- 🔊 Sound activity
- 📳 Vibration patterns
- 🚨 Alert status

---

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 🛠️ Tech Stack

<div align="center">

![ESP32](https://img.shields.io/badge/ESP32-Microcontroller-FF4500?style=for-the-badge)
![Arduino IDE](https://img.shields.io/badge/Arduino-IDE-FF6B00?style=for-the-badge)
![Embedded C](https://img.shields.io/badge/Embedded-C/C++-FF8C00?style=for-the-badge)
![IoT](https://img.shields.io/badge/IoT-WiFi%20%26%20HTTP-D35400?style=for-the-badge)
![Cloud](https://img.shields.io/badge/Cloud-Integration-FF4500?style=for-the-badge)

</div>

---

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 📦 Required Libraries & Board Setup

Before running the project, install the required **ESP32 board package** and all **Arduino libraries**.

<div align="center">

![ESP32](https://img.shields.io/badge/ESP32-Espressif%20Systems-FF4500?style=for-the-badge)
![BME280](https://img.shields.io/badge/Adafruit_BME280-Library-FF6B00?style=for-the-badge)
![BMP280](https://img.shields.io/badge/Adafruit_BMP280-Library-FF8C00?style=for-the-badge)
![BMP085](https://img.shields.io/badge/Adafruit_BMP085-Library-D35400?style=for-the-badge)
![BusIO](https://img.shields.io/badge/Adafruit_BusIO-Library-FF4500?style=for-the-badge)
![GFX](https://img.shields.io/badge/Adafruit_GFX-Library-FF6B00?style=for-the-badge)
![SSD1306](https://img.shields.io/badge/Adafruit_SSD1306-Library-FF8C00?style=for-the-badge)
![Unified](https://img.shields.io/badge/Adafruit_Unified_Sensor-Library-D35400?style=for-the-badge)

</div>

---

### 🔌 Required Board / Module

Install the following board package from **Arduino IDE Board Manager**:

```text
ESP32 by Espressif Systems
```

### ⚙️ Install ESP32 Board Package

```text
Arduino IDE → Tools → Board → Boards Manager
```

Search for:

```text
ESP32 by Espressif Systems
```

Install the latest stable version.

After installation, select:

```text
ESP32 Dev Module
```

Path:

```text
Tools → Board → ESP32 Arduino → ESP32 Dev Module
```

---

### 📚 Required Libraries

Install the following libraries from **Arduino Library Manager**:

```text
Adafruit_BME280_Library
Adafruit_BMP085_Library
Adafruit_BMP280_Library
Adafruit_BusIO
Adafruit_GFX_Library
Adafruit_SSD1306
Adafruit_Unified_Sensor
```

### ⚙️ Install via Arduino IDE

```text
Arduino IDE → Sketch → Include Library → Manage Libraries
```

Search and install each library listed above.

---

### 💻 Include Headers in Code

```cpp
#include <Wire.h>
#include <WiFi.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>
#include <Adafruit_BMP280.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
```

---

### 🧠 Setup Summary

```text
1. Install ESP32 by Espressif Systems
2. Select ESP32 Dev Module
3. Install all Adafruit libraries
4. Upload code to ESP32
5. Start live cloud monitoring
```

---

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

## 🚀 Future Enhancements

- 📍 GPS-based alert location
- ☀️ Solar-powered deployment
- 🤖 AI-based fire prediction
- 📱 Mobile app integration
- 🏢 Government dashboards

---

## 🌐 Connect with Me

<div align="center">

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Zameer%20Shaikh-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/zameer-shaikh-1a9482345)
[![GitHub](https://img.shields.io/badge/GitHub-Zameer17-181717?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Zameer17)

<br/>

<div align="center">

> *"Protecting forests through intelligent monitoring."* 🔥🌲🤖

<br/>

<!-- 🔥 ALERT FOOTER -->
<img src="https://capsule-render.vercel.app/api?type=waving&color=0:1A0F0A,25:FF8C00,50:FF6B00,75:FF4500,100:1A0F0A&height=120&section=footer&animation=fadeIn" />

</div>
