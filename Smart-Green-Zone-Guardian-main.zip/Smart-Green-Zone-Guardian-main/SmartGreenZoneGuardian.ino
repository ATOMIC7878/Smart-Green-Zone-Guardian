#include <Wire.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Adafruit_BME280.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// -------- OBJECTS --------
Adafruit_BME280 bme;

// -------- OLED CONFIG --------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// -------- PIN DEFINITIONS (ESP32 DEVKIT V1) --------
#define MQ135_PIN        34
#define SOUND_PIN        35
#define DUST_PIN         32
#define VIBRATION_PIN    26
#define BUZZER_PIN       14

// -------- THRESHOLDS --------
#define GAS_THRESHOLD     3000
#define SOUND_THRESHOLD   200
#define TEMP_THRESHOLD    32
#define DUST_THRESHOLD    1800

// -------- WiFi --------
const char* ssid = "Wifi_Name";
const char* password = "password";

// -------- ThingSpeak --------
const char* tsServer = "http://api.thingspeak.com/update";
String tsApiKey = "api_key";

// -------- ThingSpeak Timing --------
unsigned long lastTS = 0;
const unsigned long tsInterval = 20000;

// -------- TWILIO CONFIG --------
const char* twilioSID  = "your_sid";
const char* twilioAuth = "auth_token";
const char* twilioFrom = "twilio_number";
const char* twilioTo   = "ur_number";

// -------- ALERT FLAGS --------
bool fireAlertSent = false;
bool loggingAlertSent = false;

// -------- SEND SMS FUNCTION --------
void sendSMS(String message) {
  WiFiClientSecure client;
  client.setInsecure();  // skip SSL verification

  HTTPClient http;
  String url = "https://api.twilio.com/2010-04-01/Accounts/" +
               String(twilioSID) + "/Messages.json";

  String body = "To=" + String(twilioTo) +
                "&From=" + String(twilioFrom) +
                "&Body=" + message;

  http.begin(client, url);
  http.setAuthorization(twilioSID, twilioAuth);
  http.addHeader("Content-Type", "application/x-www-form-urlencoded");

  int httpCode = http.POST(body);
  if (httpCode > 0) {
    Serial.println("📨 SMS Sent");
  } else {
    Serial.println("❌ SMS Failed");
  }
  http.end();
}

// -------- SETUP --------
void setup() {
  Serial.begin(9600);

  pinMode(VIBRATION_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  if (!bme.begin(0x76)) {
    Serial.println("❌ BME280 not found!");
    while (1);
  }

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("❌ OLED not found!");
    while (1);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Forest Monitor");
  display.println("System Starting...");
  display.display();
  delay(2000);

  WiFi.begin(ssid, password);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n✅ WiFi Connected");
}

// -------- LOOP --------
void loop() {

  float temperature = bme.readTemperature();
  float humidity = bme.readHumidity();

  int gasValue = analogRead(MQ135_PIN);
  int soundValue = analogRead(SOUND_PIN);
  int dustValue = analogRead(DUST_PIN);
  int vibrationDetected = digitalRead(VIBRATION_PIN);

  int dustDetected = (dustValue > DUST_THRESHOLD) ? 1 : 0;

  int fireStatus = 0;
  int loggingStatus = 0;

  if ((temperature > TEMP_THRESHOLD && gasValue > GAS_THRESHOLD) ||
      (gasValue > GAS_THRESHOLD && dustDetected)) {
    fireStatus = 1;
  }

  if (soundValue > SOUND_THRESHOLD || vibrationDetected == HIGH) {
    loggingStatus = 1;
  }

  digitalWrite(BUZZER_PIN, (fireStatus || loggingStatus) ? HIGH : LOW);

  // -------- SMS ALERTS --------
  if (fireStatus == 1 && !fireAlertSent) {
    sendSMS("🔥 ALERT!\nForest Fire Detected!\nImmediate action required.");
    fireAlertSent = true;
  }
  if (fireStatus == 0) fireAlertSent = false;

  if (loggingStatus == 1 && !loggingAlertSent) {
    sendSMS("🪵 ALERT!\nIllegal Logging Detected!\nSound/Vibration Triggered.");
    loggingAlertSent = true;
  }
  if (loggingStatus == 0) loggingAlertSent = false;

  // -------- OLED --------
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Forest Monitor");
  display.println("----------------");
  display.print("Temp : "); display.print(temperature); display.println(" C");
  display.print("Gas  : "); display.print(gasValue);   display.println(" ppm");
  display.print("Dust : "); display.print(dustValue);  display.println(" ug/m3");
  display.print("Sound: "); display.print(soundValue); display.println(" Hz");
  display.println("----------------");
  display.println(fireStatus ? "FIRE!" : loggingStatus ? "LOGGING!" : "NORMAL");
  display.display();

  // -------- ThingSpeak --------
  if (millis() - lastTS >= tsInterval && WiFi.status() == WL_CONNECTED) {
    lastTS = millis();

    HTTPClient http;
    String url = String(tsServer) + "?api_key=" + tsApiKey +
      "&field1=" + String(temperature) +
      "&field2=" + String(gasValue) +
      "&field3=" + String(soundValue) +
      "&field4=" + String(dustValue) +
      "&field5=" + String(vibrationDetected);

    http.begin(url);
    http.GET();
    http.end();

    Serial.println("📡 Data sent to ThingSpeak");
  }

  delay(2000);
}
